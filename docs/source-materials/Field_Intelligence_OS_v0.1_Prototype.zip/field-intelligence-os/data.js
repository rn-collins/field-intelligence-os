window.FIOS_DATA = {
  notionUrl: "https://app.notion.com/p/3a3aa50422f58125925ae1c576227c7e",
  driveUrl: "https://drive.google.com/drive/folders/1H-7RzW0JbaIpSY5AKj41g_ZvLP8S8swX",
  deployments: [
    {id:"DEP-001",name:"Manhattan — September Field Deployment",city:"Manhattan",country:"United States",dates:"Sep 20–22, 2026",status:"Planning",priority:"A",mission:"48 Hours Inside the Systems Trying to Redesign the Future",drive:"https://drive.google.com/drive/folders/183zGBQXwcW5Gb76aefouGdD3XGWXOi0X",progress:28,outlets:["Independent","NSAG","JBD","Portfolio Professional"],next:"Secure Climate Week access and side meetings."},
    {id:"DEP-002",name:"Reykjavík Cannabis and Psychoactive-Plant Residency",city:"Reykjavík",country:"Iceland",dates:"Sep 20–26, 2026",status:"Planning",priority:"A",mission:"A Small Island Decides What Plant Medicine Means",drive:"https://drive.google.com/drive/folders/18410xgawqzR1l7JCqdemBIEa7wL88fp_",progress:34,outlets:["Fat Nugs","Cannabis Law Report","NSAG","JBD"],next:"Request interviews and confirm final-day conference access."}
  ],
  targets:[
    {name:"Regenerative Systems Summit",deployment:"Manhattan",type:"Event",priority:"A",lane:"JBD / NSAG / Cannes",status:"Ready to Contact",ask:"Press access and island-relevant speakers",evidence:"Lifecycle, ownership, governance and implementation evidence"},
    {name:"Datamaran",deployment:"Manhattan",type:"Organization",priority:"A",lane:"AI / Legal Tech / NSAG",status:"Ready to Contact",ask:"Product-governance interview and real workflow demo",evidence:"Methodology, source weighting, limits and client case"},
    {name:"PwC Climate Week sessions",deployment:"Manhattan",type:"Event",priority:"A",lane:"AI / Finance / Hawaiʻi",status:"Researching",ask:"Access to AI-data and capital-project sessions",evidence:"Case project, risk model, governance and outcomes"},
    {name:"Icelandic Medicines Agency",deployment:"Reykjavík",type:"Institution",priority:"A",lane:"Fat Nugs / CLR / NSAG",status:"Ready to Contact",ask:"Regulatory interview and classification exercise",evidence:"Current law, authorized products, import and enforcement data"},
    {name:"Dr. Magnús Þórsson",deployment:"Reykjavík",type:"Person",priority:"A",lane:"Fat Nugs / Science Communication",status:"Ready to Contact",ask:"Clinical evidence and access interview",evidence:"Guidelines, publications and pathway constraints"},
    {name:"University of Iceland wastewater researchers",deployment:"Reykjavík",type:"Research Team",priority:"A",lane:"Fat Nugs / NSAG",status:"Ready to Contact",ask:"Lab-method and uncertainty interview",evidence:"Methods, later datasets, limitations and policy use"},
    {name:"Helgi Gunnlaugsson",deployment:"Reykjavík",type:"Person",priority:"A",lane:"CLR / Policy",status:"Ready to Contact",ask:"Drug-policy history and reform interview",evidence:"Scholarship, legal history and current reform pathways"}
  ],
  claims:[
    {record:"Datamaran converts ESG signals into material corporate priorities",deployment:"Manhattan",type:"Claim",priority:"A",verification:"Unreviewed",next:"Obtain methodology, user evidence and limitation example"},
    {record:"Sativex is the primary authorized cannabis-containing medicinal product in Iceland",deployment:"Reykjavík",type:"Law/Policy",priority:"A",verification:"Partially Verified",next:"Confirm current authorization, prescribing and utilization with IMA"},
    {record:"Wastewater data can estimate population-level drug consumption but not individual use",deployment:"Reykjavík",type:"Evidence",priority:"A",verification:"Partially Verified",next:"Interview research team and obtain current methods/data"}
  ],
  captureCards:[
    {name:"Major Subject Minimum Package",items:["Exterior + entrance","Wide + medium + three details","Interview + demonstration/process","Evidence/document/interface","Before + after + unresolved clips","Room tone + distinctive ambient sound","Consent, law, documents, promises and next source"]},
    {name:"Claim + Evidence Bundle",items:["Exact claim","Claimant and context","Supporting source","Metric, population and limitation","Counterpoint or contradiction","Verification status and next step"]},
    {name:"Post-Interaction Cognition",items:["I expected…","What changed…","Strongest evidence…","What remains unresolved…","Who I now need…","What must remain restricted…"]}
  ]
};

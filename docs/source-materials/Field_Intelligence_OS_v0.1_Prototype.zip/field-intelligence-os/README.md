# Field Intelligence OS v0.1

A working static prototype for the Field Cognition and Investigation Framework.

## What works
- Command center
- Manhattan and Reykjavík deployment workspaces
- Target and evidence queues
- Mobile-friendly field capture cards
- Quick Capture records saved to browser localStorage
- Direct links to the live Notion mirror and Google Drive vault
- Installable/offline PWA shell

## Architecture
The app is the primary operational home. Notion is the readable mirror. Google Drive is the original-media and evidence vault.

## Next engineering tranche
- Authentication
- Supabase/Postgres knowledge graph
- Object storage and signed uploads
- Notion/Drive synchronization
- Media ingest, transcription and metadata extraction
- Row-level permissions and consent enforcement
